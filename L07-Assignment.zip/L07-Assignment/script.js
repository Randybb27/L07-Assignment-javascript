var grocery =["Bananas", "Milk", "Eggs", "Bacon"]
console.log(grocery)

var message =["Please pick up the following from the store:Bananas", "Milk", "Eggs", "Bacon"]

var i = 1

for (var i=0; i < grocery.length; i++) {
    console.log(grocery[i]);
}

if (grocery == 4) {
    message = true;
}

console.log(message);
